Hi, 

This is the extruder I sell. It's seriously my favourite for many reason : plastic consumption, printing time, design look, efficiency, gears pressure adjustement, everything disassemblies without destroy all appart...

And gear ratio is better (around 480step/mm depending on you hobbed bolt)


Ok for 1.75 an 3mm

Just try it, you'll forget the wade, s�riously.



You can find 3 type of Brackets : 

generic , mounting like I2 and Hotend directly mounted on big block. Fit every type of hodend, including Buda.
Groovemount & Bowden, for Head (closer) up to 3 heads
Groovemount & bowden, for metal head like Fourmi Simple One or E3D up to 3 heads
Groovemount & directinfill (My favourite) 

Ask for help and source if I did not put them onto Github : Jpabraham@excellence3d.com

Good Drints ! ("3d prints" sound horrible.... drint is fine !)

